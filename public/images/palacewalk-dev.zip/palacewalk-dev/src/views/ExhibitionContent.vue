<template>
  <h1>展覽內容</h1>
</template>