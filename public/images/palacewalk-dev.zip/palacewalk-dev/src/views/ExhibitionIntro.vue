<template>
  <h1>展覽簡介</h1>
</template>