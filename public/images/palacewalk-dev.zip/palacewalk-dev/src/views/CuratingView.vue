<template>
  <h1>策展專區</h1>
</template>