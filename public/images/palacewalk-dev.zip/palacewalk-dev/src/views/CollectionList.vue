<template>
  <h1>展品目錄</h1>
</template>