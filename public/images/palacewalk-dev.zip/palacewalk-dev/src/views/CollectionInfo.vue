<template>
  <h1>展品介紹</h1>
</template>