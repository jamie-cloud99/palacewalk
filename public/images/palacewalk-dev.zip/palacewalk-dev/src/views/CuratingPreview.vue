<template>
  <h1>展覽預覽</h1>
</template>