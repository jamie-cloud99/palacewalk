<template>
  <h1>新增展覽</h1>
</template>