<template>
  <div
    class="text-center lg:text-xl bg-[url(./images/footer-bg.jpg)] bg-blend-multiply bg-light py-16 lg:py-20"
  >
  
    <div class="container">
      <p>Copyright © 2023 故宮走走 All rights reserved.</p>
    </div>
  </div>
</template>

<script setup></script>
