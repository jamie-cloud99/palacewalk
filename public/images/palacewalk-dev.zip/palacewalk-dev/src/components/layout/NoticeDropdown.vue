<template>
  <div class=" hidden lg:block bg-white border-t border-dark-600 p-4 shadow-lg h-fit overflow-hidden">
    <ul class="space-y-2 px-2 divide-y divide-dark-600 w-[300px]">
      <li class="flex flex-wrap items-center py-2">
        <p class=""><span class="font-bold mr-1">瑪麗安娜</span>收藏了你的展覽</p>
        <p class="ml-auto text-sm text-dark-600">1 小時</p>
      </li>
      <li class="flex flex-wrap items-center py-2">
        <p>提醒您：你收藏的展覽 <span class="font-bold">《宋代大幅山水特展》</span> 即將下架</p>
        <p class="ml-auto text-sm text-dark-600">23 小時</p>
      </li>
    </ul>
  </div>
</template>

<script setup></script>
